<?php

namespace Database\Seeders;

use App\Models\Room;
use Illuminate\Database\Seeder;

class RoomSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Room::truncate();

        Room::create([
            'title' => "101"
        ]);

        Room::create([
            'title' => "102"
        ]);
    }
}
