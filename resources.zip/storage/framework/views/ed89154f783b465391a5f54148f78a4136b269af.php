

<?php $__env->startSection('content'); ?>
<section>
           <!-- Page content-->
           <div class="content-wrapper">

            <div class="container-fluid">
              <div class="panel panel-default">
              <div class="panel-body">

                <div class="table-responsive">
                              <table id="datatable2" class="table table-striped table-hover">
                                 <thead>
                                    <tr>
                                       <th>Customer Details</th>
                                       <th>Floor & Room</th>
                                       <th>From date</th>
                                       <th>To date</th>
                                       <th>Checkin Time</th>
                                       <th>Status</th>
                                       <th>Change Status</th>
                                       
                                    </tr>
                                 </thead>
                                 <tbody>
                                     <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td><?php echo e($registration->user_profile->name); ?>,<?php echo e($registration->user_profile->gender); ?>,<?php echo e($registration->user_profile->address); ?>,<?php echo e($registration->user_profile->contact_no); ?></td>
                                      <td><?php echo e($registration->floor->title); ?>-<?php echo e($registration->room->title); ?></td>
                                      <td><?php echo e($registration->from_date); ?></td>
                                      <td><?php echo e($registration->to_date); ?></td>
                                      <td><?php echo e($registration->check_in); ?></td>
                                      <td><?php echo e($registration->registration_status->title); ?></td>
                                      <td>
                                      <p id="registration_id" name ="registration_id" hidden><?php echo e($registration->id); ?></p>
                                      <select id="registration_status_id" name="registration_status_id" class="form-group" >
                                      <option value="" selected disabled>Select</option>
                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status->id); ?>"> <?php echo e($status->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <a href="" onclick="add('<?php echo e($registration->id); ?>')"><i class="fa fa-pencil-square-o"></i></a> 

                                     </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                 </tbody>
                              </table>
                           </div>


               </div>
            </div>



          </div>
        </section>
        <script src="<?php echo e(asset('design/jquery.js')); ?>"></script>
        
<script type="text/javascript">
        function add(id)
        {
            var status_id = $('#registration_status_id').val();
            var token = $('meta[name="csrf-token"]').attr('content');

            console.log(status_id+" "+id);
            $.ajax({

           type:"POST",
           url:"<?php echo e(url('updateRegistration')); ?>",
           data: {status_id :status_id,
            id : id,
            _token:token},
           success:function(res){ 
           console.log(res);              
            if(res){
                alert(res);
            }else{
               $("#state").empty();
            }
           }
        });
        }
        </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\voyager\hotel-app\resources\views/admin/index.blade.php ENDPATH**/ ?>